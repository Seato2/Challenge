package main.services;

import main.model.Department;
import main.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class DepartmentService {
    @Autowired
    private DepartmentRepository departmentRepository;


    public Department createDepartment(Department department){
        return departmentRepository.save(department);
    }
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    public Department getDepartmentById(Long departmentId) {
        return departmentRepository.findById(departmentId).orElse(null);
    }

    public Department updateDepartment(Department updatedDepartment) {
        return departmentRepository.save(updatedDepartment);
    }

    public void deleteDepartmentById(Long departmentId) {
        departmentRepository.deleteById(departmentId);
    }
}


