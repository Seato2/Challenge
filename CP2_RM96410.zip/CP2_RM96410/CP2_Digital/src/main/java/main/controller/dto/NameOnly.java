package main.controller.dto;

public interface NameOnly {
    String getname();
}
