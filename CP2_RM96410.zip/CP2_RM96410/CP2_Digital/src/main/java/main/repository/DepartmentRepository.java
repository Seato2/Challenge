package main.repository;


import main.controller.dto.NameOnly;
import main.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;


public interface DepartmentRepository extends JpaRepository<Department, Long> {

    Collection<NameOnly> findAllByName(String name);

}
