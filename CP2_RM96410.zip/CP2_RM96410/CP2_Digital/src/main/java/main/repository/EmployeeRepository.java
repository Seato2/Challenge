package main.repository;

import main.controller.dto.NameOnly;

import main.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;


@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findBySalaryBetween(double minSalary, double maxSalary);

    @Query(nativeQuery = true, value = "SELECT d.name AS department_name, AVG(e.salary) AS avg_salary " +
            "FROM Department d " +
            "INNER JOIN Employee e ON d.id = e.department_id " +
            "GROUP BY d.name")
    List<Object[]> findAverageSalaryByDepartment();

    @Query("SELECT e FROM Employee e WHERE e.salary BETWEEN :minSalary AND :maxSalary")
    List<Employee> findEmployeesBySalaryRange(@Param("minSalary") double minSalary, @Param("maxSalary") double maxSalary);


}
